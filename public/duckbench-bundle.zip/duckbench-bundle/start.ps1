# Start the duck bench. Run this in PowerShell from the folder it sits in.
$ErrorActionPreference = "Stop"
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host "Node.js is not installed. Get it from https://nodejs.org (LTS), then run this again."
  exit 1
}
Set-Location "$PSScriptRoot\sim"
if (-not (Test-Path node_modules)) {
  Write-Host "Installing MuJoCo and onnxruntime (once, a couple of minutes)..."
  npm install --no-audit --no-fund
}
# The phone reaches this over Tailscale, so it has to listen on every
# interface, not just localhost. duckbench already binds 0.0.0.0.
Write-Host ""
Write-Host "Starting the bench. Leave this window open."
Write-Host "In Duck Studio, use this address:" -ForegroundColor Green
$ts = (tailscale ip -4 2>$null)
if ($ts) { Write-Host "    $ts`:8770" -ForegroundColor Green }
else { Write-Host "    <this machine's Tailscale IP>:8770" -ForegroundColor Green }
Write-Host ""
node duckbench.mjs
