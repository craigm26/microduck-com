The duck bench
==============

This is the physics your phone does not have. Duck Studio can read a policy,
fingerprint it and blend it; it cannot run one, because an iPhone has no
MuJoCo. This does, and the phone talks to it over your Tailscale network.

WHAT YOU NEED
  - Node.js (LTS) from https://nodejs.org
  - Tailscale, signed in to the same account as the phone

TO START IT
  Windows:  right-click start.ps1 -> Run with PowerShell
  Mac/Linux: ./start.sh

  The first start installs MuJoCo and onnxruntime and takes a couple of
  minutes. Every start after that is a few seconds.

IN THE APP
  Duck Studio -> Policies -> Run on your network, and enter the address the
  start script prints. It is your Tailscale IP and port 8770 — something like
  100.95.79.116:8770.

  The phone and this machine do NOT need to be on the same Wi-Fi. That is the
  point of using the Tailscale address rather than a 192.168 one: it works from
  a phone on cellular.

IF YOU WANT A PASSWORD ON IT
  Set DUCKBENCH_TOKEN before starting, and put the same string in the app's
  token field:
      Windows:  $env:DUCKBENCH_TOKEN = "something-long"; .\start.ps1
      Mac/Linux: DUCKBENCH_TOKEN=something-long ./start.sh

  Without it the bench is open to anything that can reach it on your tailnet.
  A tailnet is not the public internet, so this is a real choice rather than an
  emergency, but on a shared machine set one.

THE WORLD THIS RUNS
  scene.mjb, sha256 3f8c9ab9b409ba74c73c30179d5f7c12b025f631693f9eec78d80dca242547be

  Every measurement the bench reports is against that file, and /health says so.
  A number recorded on a different plant is not comparable to one recorded here,
  which is why the digest travels with the bundle instead of just the filename.
