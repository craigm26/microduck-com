#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/sim"
command -v node >/dev/null || { echo "Node.js is not installed."; exit 1; }
[ -d node_modules ] || npm install --no-audit --no-fund
echo "In Duck Studio, use: $(tailscale ip -4 2>/dev/null | head -1 || echo '<this machine>'):8770"
exec node duckbench.mjs
